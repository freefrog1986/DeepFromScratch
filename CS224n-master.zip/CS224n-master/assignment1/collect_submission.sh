rm -f assignment1.zip
zip -r assignment1.zip *.py *.png saved_params_40000.npy
